import pyglet, os, datetime, random, math
from pyglet.window import key
from pyglet import clock
from random import randint

gameFolder = os.path.dirname(os.path.realpath(__file__))
assetsFolder = os.path.join(gameFolder,"assets")
pyglet.resource.path = [assetsFolder]
pyglet.options['audio'] = ('openal', 'pulse', 'directsound', 'silent')

width = 1280
height = 720

sky = pyglet.graphics.OrderedGroup(2)
background = pyglet.graphics.OrderedGroup(1)
foreground = pyglet.graphics.OrderedGroup(0)
groundTexture = pyglet.resource.image("grass.png")
skyTexture = pyglet.resource.image("sky.png")
skySprite = pyglet.sprite.Sprite(skyTexture, x=0, y=0, group=sky)
playerStill = pyglet.resource.image("PlayerStill.png")
playerLeft = pyglet.resource.image("PlayerLeft.png")
playerRight = pyglet.resource.image("PlayerRight.png")
playerUp = pyglet.resource.image("PlayerUp.png")
playerDown = pyglet.resource.image("PlayerDown.png")
playerSprite = pyglet.sprite.Sprite(playerStill, x=0, y=70, group=foreground)
icon1 = pyglet.resource.image("16x16.png")
icon2 = pyglet.resource.image("32x32.png")

pressedKeys = {}
alive = 1
moving = False
xVel = 0
yVel = 0

# The game window
class Window(pyglet.window.Window):

    def __init__(self):
        super(Window, self).__init__(width = width, height = height, vsync = True, caption="Platformer")
        # Run "self.update" 120 frames a second and set FPS limit to 120.
        self.set_icon(icon1,icon2)
        pyglet.clock.schedule_interval(self.update, 1.0/120.0)
        pyglet.clock.schedule_interval(self.physics, 1.0/120.0)

    def update(self, dt):
        self.check_bounds(playerSprite)

    def on_draw(self):
        pyglet.clock.tick() # Make sure you tick the clock!
        self.clear()
        skySprite.draw()
        self.create_ground()
        playerSprite.draw()
        print("FPS:" + str(round(pyglet.clock.get_fps(), 2)))

    def on_key_release(dt, symbol, modifiers):
        try:
            del pressedKeys[symbol]
        except:
            pass

    def on_key_press(dt, symbol, modifiers):
        if symbol == key.ESCAPE:
            pyglet.app.exit()
        pressedKeys[symbol] = True

    def physics(dt, dts):
        global xVel, yVel, moving
        moving = False
        if key.W in pressedKeys:
            if playerSprite.y < 75:
                yVel = 7.5
                playerSprite.image = playerUp
                moving = True
        if key.S in pressedKeys:
            yVel -= 2
            playerSprite.image = playerDown
            moving = True
        if key.A in pressedKeys:
            xVel -= 1
            playerSprite.image = playerLeft
            moving = True
        if key.D in pressedKeys:
            xVel += 1
            playerSprite.image = playerRight
            moving = True
        if (playerSprite.y) == 720:
            playerSprite.y = 656
        xVel = xVel * 0.85
        yVel -= 0.25
        if xVel < 0.01 and xVel > -0.01:
            xVel = 0
        if yVel < 0.01 and yVel > -0.01:
            yVel = 0
        if not(moving):
            playerSprite.image = playerStill
        playerSprite.x += xVel
        playerSprite.y += yVel

    def check_bounds(dt, spriteNam):
        global xVel, yVel
        min_x = 0
        min_y = 70
        max_x = 1220
        max_y = 660
        if spriteNam.x < min_x:
            spriteNam.x = min_x
            xVel = 0
        elif spriteNam.x > max_x:
            spriteNam.x = max_x
            xVel = 0
        if spriteNam.y < min_y:
            spriteNam.y = min_y
            yVel = 0
        elif spriteNam.y > max_y:
            spriteNam.y = max_y
            yVel = 0

    def create_ground(dt):
        x = 0
        while x < 1280:
            groundSprite = pyglet.sprite.Sprite(groundTexture, x=x, y=0, group=background)
            groundSprite.draw()
            x += 70

# Create a window and run
win = Window()
pyglet.app.run()
